#
java -cp lib/Ab.jar Main bot=super action=chat trace=false



