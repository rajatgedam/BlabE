



library('sentimentr')

#data <- Twitter.sentiment.self.drive.DFE
data5 <- read.csv("Twitter-sentiment-self-drive-DFE.csv")
tweets <- data5[,ncol(data5)]
tweets

for(i in tweets){
  x <- sentiment(i)
  print(x)
  
}














