data1=read.csv("dataset.csv",header = TRUE)
a=data.frame(data1)
train=head(a,200)
dim(train)
testdata=tail(a,800)
dim(testdata)
train
testdata
mytree=rpart(Membertype~Startnumber+Endnumber,data=testdata,method="class",maxdepth=3,minsplit=2,minbucket=1)
rpart.plot(mytree)

table(data1$Membertype)


#g<-runif(nrow(data1))
#data1[order(g),]

# there is two type of method learned anova and class resp. 