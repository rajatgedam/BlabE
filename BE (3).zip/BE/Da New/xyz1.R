iris=read.csv("iris.data.csv",header=TRUE)
names(iris)
print("IRIS dataset features: ")
dim(iris)
View(iris)

sepal_length<-iris$Sepal_length
sepal_width<-iris$Sepal_width
petal_length<-iris$Petal_length
petal_width<-iris$Petal_width


print("Minimum of Sepal Length: ")
print(min(sepal_length))
print("Minimum of Sepal Width: ")
print(min(sepal_width))
print("Minimum of Petal Length: ")
print(min(petal_length))
print("Minimum of Petal width: ")
print(min(petal_width))

print("Maximum of Sepal Length: ")
print(max(sepal_length))
print("Maximum of Sepal Width: ")
print(max(sepal_width))
print("Maximum of Petal Length: ")
print(max(petal_length))
print("Maximum of Petal width: ")
print(max(petal_length))

print("Mean of Sepal Length: ")
print(mean(sepal_length))
print("Mean of Sepal Width: ")
print(mean(sepal_width))
print("Mean of Petal Length: ")
print(mean(petal_length))
print("Mean of Petal width: ")
print(mean(petal_length))

print("Range of Sepal Length: ")
print(range(sepal_length))
print("Range of Sepal Width: ")
print(range(sepal_width))
print("Range of Petal Length: ")
print(range(petal_length))
print("Range of Petal width: ")
print(range(petal_length))
 
print("Variance of Sepal Length: ")
print(var(sepal_length))
print("Range of Sepal Width: ")
print(var(sepal_width))
print("Range of Petal Length: ")
print(var(petal_length))
print("Range of Petal width: ")
print(var(petal_length))

print("Standard Deviation of Sepal Length: ")
print(sd(sepal_length))
print("Standard Deviation of Sepal Width: ")
print(sd(sepal_width))
print("Standard Deviation of Petal Length: ")
print(sd(petal_length))
print("Standard Deviation of Petal Width: ")
print(sd(petal_width))

hist(sepal_length,main="Histogram of sepal_length(cm)",col="red")
hist(sepal_width,main="Histogram of sepal_width(cm)")
hist(petal_length,main="Histogram of petal_length(cm)")
hist(petal_width,main="Histogram of petal_width(cm)")

var<-boxplot(iris[,-5])
var$out

summary(iris)
library(rpart)
library(rpart.plot)
tree1<-rpart(iris$Species~iris$Sepal_length+iris$Sepal_width+iris$Petal_length+iris$Petal_width,method="anova")
rpart.plot(tree1)




#boxplot(sepal_length~iris$Species)
#plot(petal_length,petal_width,main="Graph")

#plot(petal_length,petal_width,pch=25,bg=c("red","yellow","green")[unclass(iris$Species)])

#c(23,24,25)[unclass(iris$Species)]

#pairs(iris[1:4])
