library(e1071)
mydata<-read.csv(file = "pima.csv", header = TRUE,sep = ",")
bound<-floor((nrow(mydata)/4)*3)
train<-mydata[1:bound,]
test<-mydata[(bound+1):nrow(mydata),]
fit<-naiveBayes(diabetes~.,data = train)
print(fit)
predictions <- predict(fit, test[,1:8])
table(predictions,test$diabetes)



